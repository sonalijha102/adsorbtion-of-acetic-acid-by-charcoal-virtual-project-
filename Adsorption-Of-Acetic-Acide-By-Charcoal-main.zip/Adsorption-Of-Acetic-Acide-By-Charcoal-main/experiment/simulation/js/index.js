var message=[
  "Make yourself familiar with the insturments by hovering over them after hovering click on next button ",
  "Click on Oxalic Acid and Measure 10 ML Oxalic Acid Solution",
  "Click on Measuring Cylinder",
  "Again Click on Oxalic Acid and Measure 10 ML Oxalic Acid Solution",
  "Again Click on Measuring Cylinder",
  "Again Click on Oxalic Acid and Measure 10 ML Oxalic Acid Solution",
  "Again Click on Measuring Cylinder",
  "Click on Next button",
  "Click on Phenolphthalein Indicator and add few drop into 10ML oxalic acid solution",
  "Again Click on Phenolphthalein Indicator and add few drop into 10ML oxalic acid solution",
  "Again Click on Phenolphthalein Indicator and add few drop into 10ML oxalic acid solution",
  "Click on Next button",
  "Click on the S1 Conical Flask",
  "Click on the knob until the  oxalic acid solution colour turn into pink",
  "Click on the taitrated pink conaical Flask",
  " Again click on the  next S2 Conical Flask",
  " Again click on the knob until the oxalic acid solution colour turn into pink",
  "Click on the taitrated pink conaical Flask",
  " Again click on the  next S3 Conical Flask",
  " Again click on the knob until the oxalic acid solution colour turn into pink",
  "Click on the taitrated pink conaical Flask",
  "Click on the next button",
  //tatitration of five flask acetic acid
  "Click on Phenolphthalein Indicator for preparing the  unknown set of acetic acid stock solution",
  "Again Click on Phenolphthalein Indicator for preparing the unknown set of acetic acid stock solution",
  "Again Click on Phenolphthalein Indicator for preparing the unknown set of acetic acid stock solution",
  "Again Click on Phenolphthalein Indicator for preparing the unknown set of acetic acidstock solution",
  "Again Click on Phenolphthalein Indicator for preparing the unknown set of acetic acid stock solution",
  "Click on the next button",
  "Click on the U1 Conical Flask",
  "Click on the knob until the  acetic acid solution colour turn into pink",
  "Click on the taitrated pink conaical Flask",
  // "Click on the taitrated pink conaical plask",
  " Again click on the  U2 Conical Flask",
  " Again click on the knob until the acetic acid solution colour turn into pink",
  "Click on the taitrated pink conaical Flask",
  // "Click on the taitrated pink conaical plask",
  " Again click on the U3 Conical Flask",
  " Again click on the knob until the acetic acid solution colour turn into pink",
  "Click on the taitrated pink conaical Flask",
  // "Click on the taitrated pink conaical plask",
  " Again click on the  U4 Conical Flask",
  " Again click on the knob until the acetic acid solution colour turn into pink",
  "Click on the taitrated pink conaical Flask",
  // "Click on the taitrated pink conaical plask",
  " Again click on the U5 Conical Flask",
  " Again click on the knob until the acetic acid solution colour turn into pink",
  "Click on the taitrated pink conaical plask",
  // "Click on the taitrated pink conaical plask",
  "Click on the next button",
  // weing charcole message
  "Turn on the Weingmachine for weighing 1gm Charcoal",
  "Click on the empty  Petri dish",
  "click on Tare button",
  "Click on Spatula",
  "Again click on Spatula",
  "Click on the weighing 1gm charcoal petri disk and pour into the acetic acid solution",
  "Again Click on the empty Petri dish",
  "Again click on Tare button",
  "Again Click on Spatula",
  "Again Click on Spatula",
  "Again click on the weighing 1gm charcoal petri disk and pour into the acetic acid solution",
  "Again Click on the empty Petri dish",
  "Again click on Tare button",
  "Again Click on Spatula",
  "Again Click on Spatula",
  "Again click on the weighing 1gm charcoal petri disk and pour into the acetic acid solution",
  "Again Click on the empty Petri dish",
  "Again click on Tare button",
  "Again Click on Spatula",
  "Again Click on Spatula",
  "Again click on the weighing 1gm charcoal petri disk and pour into the acetic acid solution",
  "Again Click on the empty Petri dish",
  "Again click on Tare button",
  "Again Click on Spatula",
  "Again Click on Spatula",
  "Again click on the weighing 1gm charcoal petri disk and pour into the acetic acid solution",
  "Click on the next button",
  "Turn on the main switch",
  " turn on the power button of the magnatic machine",
  "Click on the conical flask ",
  "Click on the next conical flask ",
  "Click on the next conical flask ",
  "Click on the next conical flask ",
  "Click on the next conical flask ",
  "Click on the magnet",
  "Click on the heat switch for setting the temprature",
  "Click on the speed switch for mixing the solution",
  "The solution of acetic acid and charcoal is ready and Click on the next button ",
  // filterated sollution message
  "Click on the K1 conical flask solution for filtering the charcol solution",
  "Click on the filtered acetic acid solution",
  "Click on the  next K2 conical flask solution for filtering the charcoal solution",
  "Click on the filtered acetic acid solution",
  "Click on the  next K3 conical flask solution for filtering the charcoal solution",
  "Click on the filtered acetic acid solution",
  "Click on the  next K4 conical flask solution for filtering the charcoal solution",
  "Click on the filtered acetic acid solution",
  "Click on the  next K5 conical flask solution for filtering the charcoal solution",
  "Click on the filtered acetic acid solution",
  "Click on the next button",
  "Click on the  K1 Conical Flask",
  "Click on the knob until the  acetic acid solution colour turn into pink",
  "Click on the taitrated pink conaical plask",
  " Again click on the  next K2 Conical Flask",
  " Again click on the knob until the acetic acid solution colour turn into pink",
  "Click on the taitrated pink conaical plask",
  " Again click on the  next K3 Conical Flask",
  " Again click on the knob until the acetic acid solution colour turn into pink",
  "Click on the taitrated pink conaical plask",
  " Again click on the  next K4 Conical Flask",
  " Again click on the knob until the acetic acid solution colour turn into pink",
  "Click on the taitrated pink conaical plask",
  " Again click on the  next K5 Conical Flask",
  " Again click on the knob until the acetic acid solution colour turn into pink",
  "Click on the taitrated pink conaical plask",
  "click on the next button for filling the final taitration table",
  "Analysis the tables and fill the final value and click on check button for checking your final answer ",
  "Now values are filled and you pratical has been completly succesfull.",
  
 
  ]
  
  var hmessage=[
    "अगले बटन पर क्लिक करने के बाद उन पर मंडराते हुए उपकरणों से खुद को परिचित कराएं",
    "ऑक्सालिक एसिड पर क्लिक करें और दस एमएल ऑक्सालिक एसिड समाधान मापें",
    "मापने वाले सिलेंडर पर क्लिक करें",
    "फिर से ऑक्सालिक एसिड पर क्लिक करें और 10 एमएल ऑक्सालिक एसिड घोल मापें",
    "फिर से मापने वाले सिलेंडर पर क्लिक करें",
    "फिर से ऑक्सालिक एसिड पर क्लिक करें और 10 एमएल ऑक्सालिक एसिड घोल मापें",
    "फिर से मापने वाले सिलेंडर पर क्लिक करें",
    "अगला बटन पर क्लिक करें",
    "फिनोलफथेलिन संकेतक पर क्लिक करें और 10 एमएल ऑक्सालिक एसिड घोल में कुछ बूंदें डालें",
    "फिर से फेनोल्फथेलिन संकेतक पर क्लिक करें और 10 एमएल ऑक्सालिक एसिड घोल में कुछ बूंदें डालें",
    "फिर से फेनोल्फथेलिन संकेतक पर क्लिक करें और 10 एमएल ऑक्सालिक एसिड घोल में कुछ बूंदें डालें",
    "अगला बटन पर क्लिक करें",
    "S1 शंक्वाकार फ्लास्क पर क्लिक करें",
    "घुंडी पर तब तक क्लिक करें जब तक ऑक्सालिक एसिड घोल का रंग गुलाबी न हो जाए",
    "टैट्रेटेड गुलाबी शंक्वाकार फ्लास्क पर क्लिक करें",
    "फिर से अगले S2 शंक्वाकार फ्लास्क पर क्लिक करें",
    "फिर से नॉब पर तब तक क्लिक करें जब तक ऑक्सालिक एसिड घोल का रंग गुलाबी न हो जाए",
    "टैट्रेटेड गुलाबी शंक्वाकार फ्लास्क पर क्लिक करें",
    "फिर से अगले S3 शंक्वाकार फ्लास्क पर क्लिक करें",
    "फिर से नॉब पर तब तक क्लिक करें जब तक ऑक्सालिक एसिड घोल का रंग गुलाबी न हो जाए",
    "टैट्रेटेड गुलाबी शंक्वाकार फ्लास्क पर क्लिक करें",
    "अगले बटन पर क्लिक करें",
    //tatitration of five flask acetic acid
    "एसिटिक एसिड स्टॉक समाधान के अज्ञात सेट को तैयार करने के लिए फेनोल्फथेलिन संकेतक पर क्लिक करें",
  "एसिटिक एसिड स्टॉक समाधान के अज्ञात सेट को तैयार करने के लिए फिर से फेनोल्फथेलिन संकेतक पर क्लिक करें",
  "एसिटिक एसिड स्टॉक समाधान के अज्ञात सेट को तैयार करने के लिए फिर से फेनोल्फथेलिन संकेतक पर क्लिक करें",
  "एसिटिक एसिडस्टॉक समाधान के अज्ञात सेट को तैयार करने के लिए फिर से फेनोल्फथेलिन संकेतक पर क्लिक करें",
  "एसिटिक एसिड स्टॉक समाधान के अज्ञात सेट को तैयार करने के लिए फिर से फेनोल्फथेलिन संकेतक पर क्लिक करें",
  "अगले बटन पर क्लिक करें",
  "U1 शंक्वाकार फ्लास्क पर क्लिक करें",
  "घुंडी पर तब तक क्लिक करें जब तक कि एसिटिक एसिड घोल का रंग गुलाबी न हो जाए",
  "टैट्रेटेड गुलाबी शंक्वाकार फ्लास्क पर क्लिक करें",
  // "टैट्रेटेड गुलाबी शंक्वाकार प्लास्क पर क्लिक करें",
  "फिर से U2 शंक्वाकार फ्लास्क पर क्लिक करें",
  "फिर से नॉब पर तब तक क्लिक करें जब तक कि एसिटिक एसिड घोल का रंग गुलाबी न हो जाए",
  "टैट्रेटेड गुलाबी शंक्वाकार फ्लास्क पर क्लिक करें",
  // "टैट्रेटेड गुलाबी शंक्वाकार प्लास्क पर क्लिक करें",
  "फिर से U3 शंक्वाकार फ्लास्क पर क्लिक करें",
  "फिर से नॉब पर तब तक क्लिक करें जब तक कि एसिटिक एसिड घोल का रंग गुलाबी न हो जाए",
  "टैट्रेटेड गुलाबी शंक्वाकार फ्लास्क पर क्लिक करें",
  // "टैट्रेटेड गुलाबी शंक्वाकार प्लास्क पर क्लिक करें",
  "फिर से U4 शंक्वाकार फ्लास्क पर क्लिक करें",
  "फिर से नॉब पर तब तक क्लिक करें जब तक कि एसिटिक एसिड घोल का रंग गुलाबी न हो जाए",
  "टैट्रेटेड गुलाबी शंक्वाकार फ्लास्क पर क्लिक करें",
  // "टैट्रेटेड गुलाबी शंक्वाकार प्लास्क पर क्लिक करें",
  "फिर से U5 शंक्वाकार फ्लास्क पर क्लिक करें",
  "फिर से नॉब पर तब तक क्लिक करें जब तक कि एसिटिक एसिड घोल का रंग गुलाबी न हो जाए",
  "टैट्रेटेड गुलाबी शंक्वाकार प्लास्क पर क्लिक करें",
  // "टैट्रेटेड गुलाबी शंक्वाकार प्लास्क पर क्लिक करें",
  "अगले बटन पर क्लिक करें",
   // weing charcole message
   "1 ग्राम चारकोल तोलने के लिए वेइंग मशीन चालू करें",
  "खाली पेट्री डिश पर क्लिक करें",
  "टायर बटन पर क्लिक करें",
  "स्पैटुला पर क्लिक करें",
  "फिर से स्पैटुला पर क्लिक करें",
  "1 ग्राम वजन वाली चारकोल पेट्री डिस्क पर क्लिक करें और एसिटिक एसिड घोल में डालें",
  "फिर से खाली पेट्री डिश पर क्लिक करें",
  "फिर से तारे बटन पर क्लिक करें",
  "फिर से स्पैटुला पर क्लिक करें",
  "फिर से स्पैटुला पर क्लिक करें",
  "फिर से 1 ग्राम वजन वाली चारकोल पेट्री डिस्क पर क्लिक करें और एसिटिक एसिड घोल में डालें",
  "फिर से खाली पेट्री डिश पर क्लिक करें",
  "फिर से तारे बटन पर क्लिक करें",
  "फिर से स्पैटुला पर क्लिक करें",
  "फिर से स्पैटुला पर क्लिक करें",
  "फिर से 1 ग्राम वजन वाली चारकोल पेट्री डिस्क पर क्लिक करें और एसिटिक एसिड घोल में डालें",
  "फिर से खाली पेट्री डिश पर क्लिक करें",
  "फिर से तारे बटन पर क्लिक करें",
  "फिर से स्पैटुला पर क्लिक करें",
  "फिर से स्पैटुला पर क्लिक करें",
  "फिर से 1 ग्राम वजन वाली चारकोल पेट्री डिस्क पर क्लिक करें और एसिटिक एसिड घोल में डालें",
  "फिर से खाली पेट्री डिश पर क्लिक करें",
  "फिर से तारे बटन पर क्लिक करें",
  "फिर से स्पैटुला पर क्लिक करें",
  "फिर से स्पैटुला पर क्लिक करें",
  "फिर से 1 ग्राम वजन वाली चारकोल पेट्री डिस्क पर क्लिक करें और एसिटिक एसिड घोल में डालें",
  "अगले बटन पर क्लिक करें",
  "मुख्य स्विच चालू करें",
  "मैग्नेटिक मशीन का पावर बटन चालू करें",
  "शंक्वाकार फ्लास्क पर क्लिक करें",
  "अगले शंक्वाकार फ्लास्क पर क्लिक करें",
  "अगले शंक्वाकार फ्लास्क पर क्लिक करें",
  "अगले शंक्वाकार फ्लास्क पर क्लिक करें",
  "अगले शंक्वाकार फ्लास्क पर क्लिक करें",
  "चुंबक पर क्लिक करें",
  "तापमान सेट करने के लिए हीट स्विच पर क्लिक करें",
  "समाधान मिलाने के लिए स्पीड स्विच पर क्लिक करें",
  "एसिटिक एसिड और चारकोल का घोल तैयार है और अगले बटन पर क्लिक करें",
   // filterated sollution message
   "चारकोल घोल को छानने के लिए K1 शंक्वाकार फ्लास्क घोल पर क्लिक करें",
  "फ़िल्टर किए गए एसिटिक एसिड समाधान पर क्लिक करें",
  "चारकोल घोल को छानने के लिए अगले K2 शंक्वाकार फ्लास्क घोल पर क्लिक करें",
  "फ़िल्टर किए गए एसिटिक एसिड समाधान पर क्लिक करें",
  "चारकोल घोल को छानने के लिए अगले K3 शंक्वाकार फ्लास्क घोल पर क्लिक करें",
  "फ़िल्टर किए गए एसिटिक एसिड समाधान पर क्लिक करें",
  "चारकोल घोल को छानने के लिए अगले K4 शंक्वाकार फ्लास्क घोल पर क्लिक करें",
  "फ़िल्टर किए गए एसिटिक एसिड समाधान पर क्लिक करें",
  "चारकोल घोल को छानने के लिए अगले K5 शंक्वाकार फ्लास्क घोल पर क्लिक करें",
  "फ़िल्टर किए गए एसिटिक एसिड समाधान पर क्लिक करें",
  "अगले बटन पर क्लिक करें",
  "K1 शंक्वाकार फ्लास्क पर क्लिक करें",
  "घुंडी पर तब तक क्लिक करें जब तक कि एसिटिक एसिड घोल का रंग गुलाबी न हो जाए",
  "टैट्रेटेड गुलाबी शंक्वाकार प्लास्क पर क्लिक करें",
  "फिर से अगले K2 शंक्वाकार फ्लास्क पर क्लिक करें",
  "फिर से नॉब पर तब तक क्लिक करें जब तक कि एसिटिक एसिड घोल का रंग गुलाबी न हो जाए",
  "टैट्रेटेड गुलाबी शंक्वाकार प्लास्क पर क्लिक करें",
  "फिर से अगले K3 शंक्वाकार फ्लास्क पर क्लिक करें",
  "फिर से नॉब पर तब तक क्लिक करें जब तक कि एसिटिक एसिड घोल का रंग गुलाबी न हो जाए",
  "टैट्रेटेड गुलाबी शंक्वाकार प्लास्क पर क्लिक करें",
  "फिर से अगले K4 शंक्वाकार फ्लास्क पर क्लिक करें",
  "फिर से नॉब पर तब तक क्लिक करें जब तक कि एसिटिक एसिड घोल का रंग गुलाबी न हो जाए",
  "टैट्रेटेड गुलाबी शंक्वाकार प्लास्क पर क्लिक करें",
  "फिर से अगले K5 शंक्वाकार फ्लास्क पर क्लिक करें",
  "फिर से नॉब पर तब तक क्लिक करें जब तक कि एसिटिक एसिड घोल का रंग गुलाबी न हो जाए",
  "टैट्रेटेड गुलाबी शंक्वाकार प्लास्क पर क्लिक करें",
  "अंतिम टैट्रेशन तालिका भरने के लिए अगले बटन पर क्लिक करें",
    
  ]
  
  var fillcharcoal=document.querySelector("#fillcharcoal")
  var mes=document.querySelector("#update")
  var lang
  var mes1
  messcounter = 0
  var hindibtn = document.querySelector("#hindi")
  var engbtn = document.querySelector("#eng")
  var headertext = document.querySelector("#headertext")
  var langselector = document.querySelector("#langselector")
  

  setTimeout(() => {
    update;
    s=0;
  },100);
  
  function hindi1(){
      console.log(lang)
      lang="hindi"
      //headertext.innerText="'एसिटिक' एसिड के पृथक्करण स्थिरांक को निर्धारित करने के लिए विद्युत चालकता का मापन"
      langselector.style.visibility="hidden"
      update()
  }
  
  function eng11(){
      console.log(lang)
      lang="eng"
      //headertext.innerText="Measurement of Electrical conductance to determine dissociation constant of 'Acetic' acid"
      langselector.style.visibility="hidden"
      update() 
  }
  
  
  
  function speech1(){
   speechSynthesis.cancel()
      if(lang=="hindi"){
          mes1=hmessage[messcounter-1]
          console.log(mes1)
          setTimeout(function(){ 
            //mes1=hmessage[messcounter]
            const utterance = new SpeechSynthesisUtterance(mes1);
            utterance.lang = 'hi-HI';
            utterance.pitch=1;
            utterance.rate=1;
            utterance.volume=1;
            speechSynthesis.speak(utterance);
        },500)
           
        
      }
      else if(lang=="eng"){
          mes1=message[messcounter-1]
          console.log(mes1)
          setTimeout(function(){ 
            //mes1=hmessage[messcounter]
            const utterance = new SpeechSynthesisUtterance(mes1);
            utterance.lang = 'en-EN';
            utterance.pitch=1;
            utterance.rate=1;
            utterance.volume=1;
            speechSynthesis.speak(utterance);
        },500)
      }
     
  }
 
  function update(){
      console.log(message[messcounter])
      if(lang=="hindi"){
          mes.innerText=hmessage[messcounter]
      }
      else if(lang=="eng"){
          mes.innerText=message[messcounter]
      }
      //mes.innerText=hmessage[messcounter]
      messcounter+=1
          speech1()
  }
  var charcole3=document.querySelector("#charcole3")
var meg=document.querySelector("#magnatic")
  var p1=document.querySelector("#p1")
  var p2=document.querySelector("#p2")
  var p3=document.querySelector("#p3")
  var p4=document.querySelector("#p4")
  var p5=document.querySelector("#p5")
var flask1=document.querySelector("#flask1")
var pag=0;
function nextpage(){
  if(pag==0){
    update()

    weingimage.style.visibility="hidden"
    emptyconicalflask.style.visibility="hidden"
    emptyroundflsk.style.visibility="hidden"
    roundflask11.style.visibility="hidden"
    roundflask22.style.visibility="hidden"
    aceticacidimage.style.visibility="hidden"
    buretimage.style.visibility="hidden"
    filterstand.style.visibility="hidden"
    masurcylenderimage.style.visibility="hidden"
    spertulaimage.style.visibility="hidden"
    emptypatrydiskimage.style.visibility="hidden"
    pertydiskimage.style.visibility="hidden"
    petrydiskchar.style.visibility="hidden"
    kippiimage.style.visibility="hidden"
    activatorbottelimage.style.visibility="hidden"
    activatordroperimage.style.visibility="hidden"
   
    
   weingimg.style.visibility="hidden"
    conicalflaskimg.style.visibility="hidden"
    roundflaskimg.style.visibility="hidden"
    roundflask1.style.visibility="hidden"
    roundflask2.style.visibility="hidden"
    aceticacideimg.style.visibility="hidden"
    buretimag.style.visibility="hidden"
    fiterstandimg.style.visibility="hidden"
    mesurimg.style.visibility="hidden"
    sperchulaimg.style.visibility="hidden"
    emptypatrydiskimg.style.visibility="hidden"
    activechr.style.visibility="hidden"
    kippiimg.style.visibility="hidden"
    indicatorimg.style.visibility="hidden"
   

  
  
    flask1.style.visibility="visible"
    aceticccbeaker.style.visibility="visible"
    conicaflask2.style.visibility="visible"
    conicaflask1.style.visibility="visible"
    flask22.style.visibility="visible"
    conicaflask3.style.visibility="visible"
   
    activatordeoper.style.visibility="visible"
    activaterbottel.style.visibility="visible"
   
    masurcylender.style.visibility="visible"
    // back.style.visibility="hidden"
    ss1.style.visibility="visible"
    ss2.style.visibility="visible"
    ss3.style.visibility="visible"
    o.style.visibility="visible"
    s=1;
    
  }

  else if(pag==1){
    update()
    
  
    sol2.style.transitionDuration="0s"
    sol2.style.visibility="hidden"
    aceticccbeaker.style.visibility="hidden"
    conicaflask2.style.visibility="hidden"
    conicaflask1.style.visibility="hidden"
    flask22.style.visibility="hidden"
    conicaflask3.style.visibility="hidden"
    
    activatordeoper.style.visibility="hidden"
    activaterbottel.style.visibility="hidden"
   
    masurcylender.style.transitionDuration="0s"
    masurcylender.style.visibility="hidden"
    f1sol.style.visibility="hidden"
    f2sol.style.visibility="hidden"
    f3sol.style.visibility="hidden"


    vflk1.style.visibility="visible"
    vflk2.style.visibility="visible"
    vflk3.style.visibility="visible"
   
    activaterdroper.style.visibility="visible"
    act12.style.visibility="visible"
    s1.style.visibility="visible"/*activater*/
    s2.style.visibility="visible"
    s3.style.visibility="visible"
    ss1.style.visibility="hidden"
    ss2.style.visibility="hidden"
    ss3.style.visibility="hidden"
    o.style.visibility="hidden"
    f=0;
  }
  else if(pag==2){
    update()
    k=0;
    
    vflk1.style.visibility="hidden"
    vflk2.style.visibility="hidden"
    vflk3.style.visibility="hidden"
    activaterdroper.style.visibility="hidden"
    activaterdroper.style.transitionDuration="0s"
    act12.style.transitionDuration="0s"
    act12.style.visibility="hidden"

    brstand.style.visibility="visible"
    orgflsk.style.visibility="visible"
    flask2.style.visibility="visible"
    flaskk3.style.visibility="visible"
    knob.style.visibility="visible"
    s1.style.visibility="hidden"/*tai3*/
    s2.style.visibility="hidden"
    s3.style.visibility="hidden"
    h1.style.visibility="visible"
    h2.style.visibility="visible"
    h3.style.visibility="visible"
    

    new1.style.visibility="visible"
    pflask2.style.visibility="visible"
    pflask3.style.visibility="visible"
    table.style.visibility="visible"
    
    tableh1.style.visibility="visible"
    
    

    
   
  }
  else if(pag==3){
    update()
   q=0;
   orgflsk.style.transitionDuration="0s"
   flask2.style.transitionDuration="0s"
   flaskk3.style.transitionDuration="0s"
    brstand.style.visibility="hidden"
    orgflsk.style.visibility="hidden"
    flask2.style.visibility="hidden"
    flaskk3.style.visibility="hidden"
    knob.style.visibility="hidden"
    pinkk1.style.visibility="hidden"
    pinkk2.style.visibility="hidden"
    pinkk3.style.visibility="hidden"
    pinkk1.style.transitionDuration="0s"
    pinkk2.style.transitionDuration="0s"
    pinkk3.style.transitionDuration="0s"
    table.style.visibility="hidden"
    tableh1.style.visibility="hidden"

    volflask1.style.visibility="visible"
    volflask2.style.visibility="visible"
    volflask3.style.visibility="visible"
    volflask4.style.visibility="visible"
    volflask5.style.visibility="visible"
    activater.style.visibility="visible"
    activaterdroper55f.style.visibility="visible"
    h1.style.visibility="hidden"/*act5*/
    h2.style.visibility="hidden"
    h3.style.visibility="hidden"
    u1.style.visibility="visible"
    u2.style.visibility="visible"
    u3.style.visibility="visible"
    u4.style.visibility="visible"
    u5.style.visibility="visible"
   
  }
  else if(pag==4){
    update()
   p=0;
    volflask1.style.visibility="hidden"
    volflask2.style.visibility="hidden"
    volflask3.style.visibility="hidden"
    volflask4.style.visibility="hidden"
    volflask5.style.visibility="hidden"

    volflask1.style.transitionDuration="0s"
    volflask2.style.transitionDuration="0s"
    volflask3.style.transitionDuration="0s"
    volflask4.style.transitionDuration="0s"
    volflask5.style.transitionDuration="0s"
    activater.style.transitionDuration="0s"
    activater.style.visibility="hidden"
    activaterdroper55f.style.transitionDuration="0s"
    activaterdroper55f.style.visibility="hidden"

    brstand5f.style.visibility="visible"
    f1.style.visibility="visible"
    f2.style.visibility="visible"
    f3.style.visibility="visible"
    f4.style.visibility="visible"
    aq5v.style.visibility="visible"
    knob5f.style.visibility="visible"
    // droptaitration.style.visibility="visible"
    p1.style.visibility="visible"
    p2.style.visibility="visible"
    p3.style.visibility="visible"
    p4.style.visibility="visible"
    p5.style.visibility="visible"
    table2.style.visibility="visible"
    headtb2.style.visibility="visible"
    uu1.style.visibility="visible"/*tai5*/
    uu2.style.visibility="visible"
    uu3.style.visibility="visible"
    uu4.style.visibility="visible"
    uu5.style.visibility="visible"
    u1.style.visibility="hidden"
    u2.style.visibility="hidden"
    u3.style.visibility="hidden"
    u4.style.visibility="hidden"
    u5.style.visibility="hidden"
    
   
  }
  else if(pag==5){
    update()
   m=1;
   

    brstand5f.style.visibility="hidden"
    f1.style.visibility="hidden"
    f2.style.visibility="hidden"
    f3.style.visibility="hidden"
    f4.style.visibility="hidden"
    aq5v.style.visibility="hidden"
    knob5f.style.visibility="hidden"
    droptaitration.style.visibility="hidden"
    p1.style.visibility="hidden"
    p2.style.visibility="hidden"       //im here
    p3.style.visibility="hidden"
    p4.style.visibility="hidden"
    p5.style.visibility="hidden"

    p1.style.transitionDuration="0s"
    p2.style.transitionDuration="0s"
    p3.style.transitionDuration="0s"
    p4.style.transitionDuration="0s"
    p5.style.transitionDuration="0s"
    table2.style.visibility="hidden"
    headtb2.style.visibility="hidden"
    
    weingmachine.style.visibility="visible"
    bowl1.style.visibility="visible"
    bowl2.style.visibility="visible"
    spoonempty.style.visibility="visible"
    charcole1.style.visibility="visible"
    charcole2.style.visibility="visible"
    charcole3.style.visibility="visible"
    beakercharcole1.style.visibility="visible"
    beakercharcole2.style.visibility="visible"
    beakercharcole3.style.visibility="visible"
    beakercharcole4.style.visibility="visible"
    beakercharcole5.style.visibility="visible"
    beaker1.style.visibility="visible"
    beaker2.style.visibility="visible"
    beaker3.style.visibility="visible"
    beaker4.style.visibility="visible"
    beaker5.style.visibility="visible"
    on.style.visibility="visible"
    tare.style.visibility="visible"
    uu1.style.visibility="hidden"/*weg*/
    uu2.style.visibility="hidden"
    uu3.style.visibility="hidden"
    uu4.style.visibility="hidden"
    uu5.style.visibility="hidden"
    kw1.style.visibility="visible"
    kw2.style.visibility="visible"
    kw3.style.visibility="visible"
    kw4.style.visibility="visible"
    kw5.style.visibility="visible"
   
  }
  else if(pag==6){
    update()
    u=0;
    weingmachine.style.visibility="hidden"
    bowl1.style.transitionDuration="0s"
    bowl2.style.transitionDuration="0s"
    bowl1.style.visibility="hidden"
    bowl2.style.visibility="hidden"
    spoonempty.style.transitionDuration="0s"
    spoonempty.style.visibility="hidden"
    charcole1.style.transitionDuration="0s"
    charcole2.style.transitionDuration="0s"
    charcole3.style.transitionDuration="0s"

    charcole1.style.visibility="hidden"
    charcole2.style.visibility="hidden"
    charcole3.style.visibility="hidden"
    beakercharcole1.style.visibility="hidden"
    beakercharcole2.style.visibility="hidden"
    beakercharcole3.style.visibility="hidden"
    beakercharcole4.style.visibility="hidden"
    beakercharcole5.style.visibility="hidden"
    
    beaker1.style.visibility="hidden"
    beaker2.style.visibility="hidden"
    beaker3.style.visibility="hidden"
    beaker4.style.visibility="hidden"
    beaker5.style.visibility="hidden"
    on.style.visibility="hidden"
    tare.style.visibility="hidden"
    num.style.visibility="hidden"
  


    meg.style.visibility="visible"
    stirror.style.visibility="visible"
    nobspeed.style.visibility="visible"
    nobheat.style.visibility="visible"
    powerbutton.style.visibility="visible"
    powerbuttonoff.style.visibility="visible"
    machbuttonoff.style.visibility="visible"
    powerwire.style.visibility="visible"
    black11.style.visibility="visible"
    black22.style.visibility="visible"
    black33.style.visibility="visible"
    black44.style.visibility="visible"
    black55.style.visibility="visible"
    kw1.style.visibility="hidden"/*mach*/
    kw2.style.visibility="hidden"
    kw3.style.visibility="hidden"
    kw4.style.visibility="hidden"
    kw5.style.visibility="hidden"
    mkk1.style.visibility="visible"
    mkk2.style.visibility="visible"
    mkk3.style.visibility="visible"
    mkk4.style.visibility="visible"
    mkk5.style.visibility="visible"
    

  
   
   
  }
  else if(pag==7){
    update()
    uk=0;
    hand.style.transitionDuration="0s"
    hand.style.visibility="hidden"
  meg1.style.visibility="hidden"
  meg2.style.visibility="hidden"
  meg3.style.visibility="hidden"
  meg4.style.visibility="hidden"
  meg5.style.visibility="hidden"
  meg1.style.transitionDuration="0s"
  meg2.style.transitionDuration="0s"
  meg3.style.transitionDuration="0s"
  meg4.style.transitionDuration="0s"
  meg5.style.transitionDuration="0s"
  charcole3.style.visibility="hidden"
  charcole3.style.transitionDuration="0s"

    stirror.style.visibility="hidden"
    nobspeed.style.visibility="hidden"
    nobheat.style.visibility="hidden"
    powerbutton.style.visibility="hidden"
    powerbuttonoff.style.visibility="hidden"
    machbuttonoff.style.visibility="hidden"
    powerwire.style.visibility="hidden"
    black11.style.visibility="hidden"
    black22.style.visibility="hidden"
    black33.style.visibility="hidden"
    black44.style.visibility="hidden"
    black55.style.visibility="hidden"
    // blackfi1.style.visibility="hidden"
    // blackfi2.style.visibility="hidden"
    // blackfi3.style.visibility="hidden"
    // blackfi4.style.visibility="hidden"
    // blackfi5.style.visibility="hidden"
    megnatic.style.visibility="hidden"
    powerbuttonon.style.visibility="hidden"
    machbuttonon.style.visibility="hidden"
    redlight.style.visibility="hidden"

    filterstand11.style.visibility="visible"
    bflask11.style.visibility="visible"
    bflask22.style.visibility="visible"
    bflask33.style.visibility="visible"
    bflask44.style.visibility="visible"
    bflask55.style.visibility="visible"
    readyflask11.style.visibility="visible"

    solbfi1.style.visibility="hidden"
    solbfi2.style.visibility="hidden"
    solbfi3.style.visibility="hidden"
    solbfi4.style.visibility="hidden"
    solbfi5.style.visibility="hidden"

    solbfi1.style.transitionDuration="0s"
    solbfi2.style.transitionDuration="0s"
    solbfi3.style.transitionDuration="0s"
    solbfi4.style.transitionDuration="0s"
    solbfi5.style.transitionDuration="0s"
    kkk1.style.visibility="visible"/*filt*/
    kkk2.style.visibility="visible"
    kkk3.style.visibility="visible"
    kkk4.style.visibility="visible"
    kkk5.style.visibility="visible"
    // mkk1.style.visibility="hidden"
    // mkk2.style.visibility="hidden"
    // mkk3.style.visibility="hidden"
    // mkk4.style.visibility="hidden"
    // mkk5.style.visibility="hidden"
   
  }
  else if(pag==8){
    update()
    v=0;
    acflask1.style.visibility="hidden"
    acflask2.style.visibility="hidden"
    acflask3.style.visibility="hidden"
    acflask4.style.visibility="hidden"
    acflask5.style.visibility="hidden"
    acflask1.style.transitionDuration="0s"
    acflask2.style.transitionDuration="0s"
    acflask3.style.transitionDuration="0s"
    acflask4.style.transitionDuration="0s"
    acflask5.style.transitionDuration="0s"
    filterstand11.style.visibility="hidden"
    drop11.style.visibility="hidden"
    bflask11.style.visibility="hidden"
    bflask22.style.visibility="hidden"
    bflask33.style.visibility="hidden"
    bflask44.style.visibility="hidden"
    bflask55.style.visibility="hidden"
    readyflask11.style.visibility="hidden"

    
    brstandtai.style.visibility="visible"
    f111.style.visibility="visible"
    f222.style.visibility="visible"
    f333.style.visibility="visible"
    f444.style.visibility="visible"
    f555v.style.visibility="visible"
    knob3rd.style.visibility="visible"
    p111.style.visibility="visible"
    p222.style.visibility="visible"
    p333 .style.visibility="visible"
   p444.style.visibility="visible"
   p555.style.visibility="visible"
   table111f.style.visibility="visible"
   heading33.style.visibility="visible"
   kkk1.style.visibility="hidden"/*tail*/
   kkk2.style.visibility="hidden"
   kkk3.style.visibility="hidden"
   kkk4.style.visibility="hidden"
   kkk5.style.visibility="hidden"
   kkkk1.style.visibility="visible"
kkkk2.style.visibility="visible"
kkkk3.style.visibility="visible"
kkkk4.style.visibility="visible"
kkkk5.style.visibility="visible"
   

   /*brstand3rd
   f111
   f222
   f333
   f444
   f555
   knob3rd
   p111
   p222
   p333 
  p444
  p555
  table111
  heading33*/

  }
  else if(pag==9){
    update();

    brstandtai.style.visibility="hidden"
f111.style.visibility="hidden"
f222.style.visibility="hidden"
f333.style.visibility="hidden"
f444.style.visibility="hidden"
f555v.style.visibility="hidden"
knob3rd.style.visibility="hidden"
p111.style.visibility="hidden"
p222.style.visibility="hidden"
p333 .style.visibility="hidden"
p444.style.visibility="hidden"
p555.style.visibility="hidden"
table111f.style.visibility="hidden"
heading33.style.visibility="hidden"
// kkk1.style.visibility="hidden"/*tail*/
// kkk2.style.visibility="hidden"
// kkk3.style.visibility="hidden"
// kkk4.style.visibility="hidden"
// kkk5.style.visibility="hidden"
kkkk1.style.visibility="hidden"
kkkk2.style.visibility="hidden"
kkkk3.style.visibility="hidden"
kkkk4.style.visibility="hidden"
kkkk5.style.visibility="hidden"

    submitresult.style.visibility="visible"
    he1.style.visibility="visible"
    he2.style.visibility="visible"
    he3.style.visibility="visible"
    he33.style.visibility="visible"
    he0.style.visibility="visible"
    table111.style.visibility="visible"
    table222.style.visibility="visible"
    table333.style.visibility="visible"
    usertable.style.visibility="visible"
    image.style.visibility="visible"
    next.style.visibility="hidden" 
    
  }
}

var masurwater11=document.querySelector("#masurwater")
var masurcyll=document.querySelector("#masurcylender")
var mkippi11=document.querySelector("#mkippi")
var mdrop11=document.querySelector("#mdrop")
var fkippi11=document.querySelector("#fkippi1")
var f1drop11=document.querySelector("#f1drop")
var f1sol11=document.querySelector("#f1sol")
var fkippi22=document.querySelector("#fkippi2")
var f1drop22=document.querySelector("#f2drop")
var f1sol22=document.querySelector("#f2sol")
var fkippi33=document.querySelector("#fkippi3")
var f1drop33=document.querySelector("#f3drop")
var f1sol33=document.querySelector("#f3sol")
var flask11=document.querySelector("#flask1")
var sol00=document.querySelector("#sol0")
var sol11=document.querySelector("#sol1")
var sol22=document.querySelector("#sol2")






var s;
function flask1put(){
    if(s==1){
        console.log("hello")
        flask11.style.transform = " translate(260%,-60%) rotate(80deg) ";
        
        mkippi11.style.visibility="visible";
        setTimeout (function(){
           masurwater11.style.visibility="visible";
            mdrop11.style.visibility="visible";
            setTimeout(function() {
                mdrop11.style.visibility="hidden";
            },400);
        },2200)
        setTimeout(function(){
            flask11.style.transform = " translate(0%,0%) rotate(0deg) ";
            flask11.style.visibility="hidden";
            
            mkippi11.style.visibility="hidden";
          },2800)
          setTimeout(function(){
           
         
          sol00.style.visibility="visible";
          update()
      },4000)
        s+=1; 
    }
  }
function solput0(){
  
  if(s==3){
    console.log("iuerhgeohgio")
    sol00.style.transform="translate(280%,-60%) rotate(80deg)";
    mkippi11.style.visibility="visible";
    setTimeout (function(){
       masurwater11.style.visibility="visible";
        mdrop11.style.visibility="visible";
        setTimeout(function() {
            mdrop11.style.visibility="hidden";
        },400);
    },2200)
    setTimeout(function(){
        sol00.style.transform = " translate(0%,0%) rotate(0deg) ";
        mkippi11.style.visibility="hidden";
        sol00.style.visibility="hidden";
        
    },2800)
    setTimeout(function(){
      
      sol11.style.visibility="visible";
      update()

  },4000)
    s+=1; 
       
  }
}

   function solput1() {
    if(s==5){
      console.log("hello")
      sol11.style.transform = "translate(260%,-60%) rotate(80deg)";
      
      mkippi11.style.visibility="visible";
      setTimeout (function(){
         masurwater11.style.visibility="visible";
          mdrop11.style.visibility="visible";
          setTimeout(function() {
              mdrop11.style.visibility="hidden";
          },400);
      },2200)
      setTimeout(function(){
          sol11.style.transform = " translate(0%,0%) rotate(0deg) ";
          
          sol11.style.visibility="hidden";
          mkippi11.style.visibility="hidden";
          
      },2800)
      setTimeout(function(){
        
        sol22.style.visibility="visible";
        update()
      
       

      },4000)
       s+=1; 
    }
   }

function masurcyput(){
    if(s==2){
      console.log("hello")
        masurcyll.style.transform = " translate(130%,-80%) rotate(80deg) ";
        masurwater11.style.transform = " translate(168%,-163%) rotate(80deg) ";
        fkippi11.style.visibility="visible";
        masurwater11.style.visibility="hidden";
        setTimeout (function(){
           
           
            f1drop11.style.visibility="visible";
            f1sol11.style.visibility="visible";
            
            setTimeout(function() {
                f1drop11.style.visibility="hidden";
               
            },400);
        },2200)
        setTimeout(function(){
           
        masurcyll.style.transform = " translate(0%,0%) rotate(0deg) ";
        masurwater11.style.transform = " translate(0%,-0%) rotate(0deg) ";
        fkippi11.style.visibility="hidden";
        update()
        },3000)
        s+=1;
        
    }
    else if(s==4){
        masurcyll.style.transform = " translate(330%,-80%) rotate(80deg) ";
        masurwater11.style.transform = " translate(600%,-163%) rotate(80deg) ";
        fkippi22.style.visibility="visible";
        masurwater11.style.visibility="hidden";
        setTimeout (function(){
           
           
            f1drop22.style.visibility="visible";
            f1sol22.style.visibility="visible";
            
            setTimeout(function() {
                f1drop22.style.visibility="hidden";
               
            },400);
        },2200)
        setTimeout(function(){
           
        masurcyll.style.transform = " translate(0%,0%) rotate(0deg) ";
        masurwater11.style.transform = " translate(0%,-0%) rotate(0deg) ";
        fkippi22.style.visibility="hidden";
        update()
        },3000)
        s+=1;

    }
    else if(s==6){
        masurcyll.style.transform = " translate(500%,-80%) rotate(80deg) ";
        masurwater11.style.transform = " translate(1000%,-166%) rotate(80deg) ";
        fkippi33.style.visibility="visible";
        masurwater11.style.visibility="hidden";
        setTimeout (function(){
           
           
            f1drop33.style.visibility="visible";
            f1sol33.style.visibility="visible";
            
            setTimeout(function() {
                f1drop33.style.visibility="hidden";
               
            },400);
        },2200)
        setTimeout(function(){
           
        masurcyll.style.transform = " translate(0%,0%) rotate(0deg) ";
        masurwater11.style.transform = " translate(0%,-0%) rotate(0deg) ";
        fkippi33.style.visibility="hidden";
        update()
        },3000)
        s+=1;
        pag=1;
    }
}


/*********************************step2nd******activater3*************************************************/
var f;

var activater1 = document.querySelector("#activaterdroper")
var drp0= document.querySelector("#drop0")
var drp1 = document.querySelector("#drop1")
var drp2 = document.querySelector("#drop2")
var ai =document.querySelector("arroeimage")



function act1(){
  if (f==0) {
      console.log(f)
   
   activater1.style.transform = "translate(-1300%,-160%)";
  

   setTimeout(function () {
     drp0.style.visibility = "visible";
     drp0.style.transform ="translate(0%,700%)"
    
    
   }, 2500)

   setTimeout(function () {
     act1reverse()
     drp0.style.visibility = "hidden";
   
   }, 3000);
 
   
 }

 function act1reverse() {
   drp0.style.visibility = "hidden";
  
   activater1.style.transform = "translate(0%,-0%)";
   update()
   f +=1 ;
 }
}
function act2(){
  if (f==1) {
      console.log(f)
   
   activater1.style.transform = "translate(-990%,-160%)";
  

   setTimeout(function () {
     drp1.style.visibility = "visible";
     drp1.style.transform ="translate(0%,700%)"
    
    
   }, 2500)

   setTimeout(function () {
     act2reverse()
     drp1.style.visibility = "hidden";
   
   }, 3000);
 
   
 }

 function act2reverse() {
   drp1.style.visibility = "hidden";
  
   activater1.style.transform = "translate(0%,-0%)";
   update()
   f +=1 ;
 }
}
function act3(){
  if (f==2) {
      console.log(f)
   
   activater1.style.transform = "translate(-672%,-160%)";
  

   setTimeout(function () {
     drp2.style.visibility = "visible";
     drp2.style.transform ="translate(0%,700%)"
    
    
   }, 2500)

   setTimeout(function () {
     act3reverse()
     drp2.style.visibility = "hidden";
   
   }, 3000);
 
   
 }

 function act3reverse() {
   drp2.style.visibility = "hidden";
  
   activater1.style.transform = "translate(0%,-0%)";
   f +=1 ;
   update()
   pag+=1;
 }
}
 
/**************************************************************step3 taitration 3*******************************/


var k;
var new1 = document.querySelector("#pinkk1")

var pflask2 = document.querySelector("#pinkk2")
var pflask3 = document.querySelector("#pinkk3")
var orgl = document.querySelector("#orgflsk");
var aql = document.querySelector("#flask2")
var flask3 = document.querySelector("#flaskk3")
var drpp = document.querySelector("#dropp")



function titration1() {
  if (k == 0) {
    console.log(s);
    orgl.style.transform = "translate(680%,0%) ";
     volumeo1.innerHTML ="10";
     update()
  }
k=1
  
}

function titrate() {
  if (k == 1) {
    drpp.style.visibility = "visible"
    drpp.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpp.style.visibility = "hidden"
    }, 200);

    setTimeout(() => {
      drpp.style.transform = "translate(0%,0%)"
      
    }, 1000);
    k=2;

    

  }
  else if(k==2){
    drpp.style.visibility = "visible"
    drpp.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpp.style.visibility = "hidden"
    }, 200);

    setTimeout(() => {
      drpp.style.transform = "translate(0%,0%)"
    }, 1000);

    setTimeout(() => {
     /* new1.style.opacity = "20%"
      new1.style.opacity = "60%"*/
      new1.style.opacity = "100%"
      orgl.style.visibility = "hidden";

      update()
      
     

    }, 2500);
    k=3;
   

  }
  else if (k == 5) {
    drpp.style.visibility = "visible"
    drpp.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpp.style.visibility = "hidden"
    }, 200);

    setTimeout(() => {
      drpp.style.transform = "translate(0%,0%)"
    }, 1000);
    k=6;

   

  }
  else if(k==6){
    drpp.style.visibility = "visible"
    drpp.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpp.style.visibility = "hidden"
    }, 200);

    setTimeout(() => {
      drpp.style.transform = "translate(0%,0%)"
    }, 1000);

    setTimeout(() => {
      pflask2.style.opacity = "20%"
      pflask2.style.opacity = "60%"
      pflask2.style.opacity = "100%"
      aql.style.visibility = "hidden";
      update()
     

    }, 2500);
    k=7;

  }
  else if (k == 9) {
    drpp.style.visibility = "visible"
    drpp.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpp.style.visibility = "hidden"
    }, 200);

    setTimeout(() => {
      drpp.style.transform = "translate(0%,0%)"
     
    }, 1000);

   k=10

  }
  else if(k==10){
    drpp.style.visibility = "visible"
    drpp.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpp.style.visibility = "hidden"
    }, 200);

    setTimeout(() => {
      drpp.style.transform = "translate(0%,0%)"
    }, 1000);

    setTimeout(() => {
      pflask3.style.opacity = "20%"
      pflask3.style.opacity = "60%"
      pflask3.style.opacity = "100%"
      flask3.style.visibility = "hidden";
      update()
     
      

    }, 2500);
    k=11;

  }
  
  

}
function pink1(){
  if(k==3){
    new1.style.transform = "translate(-680%,0%)";
    volumen1.innerHTML ="21";
    update()
    k=4;
  }
}
function pink2(){
  if(k==7){
    pflask2.style.transform = "translate(-480%,0%)";
    volumen2.innerHTML ="21";
    update()
    k=8
  }
}
function pink3(){
  if(k==11){
    pflask3.style.transform = "translate(-280%,0%)";
    volumen3.innerHTML ="21";
    update()
    pag=3;
    
  }
}





function titration2() {
  if (k == 4) {
    aql.style.transform = "translate(480%,0%) ";
    volumeo2.innerHTML ="10";
    update()
    k=5;

  }

}


function titration3() {
  if (k == 8) {
    flask3.style.transform = "translate(280%,0%) ";
    volumeo3.innerHTML ="10";
 update()
 
k=9;
  }

}


/************************************activetor5*****************************88 */


var q;

var activater5f = document.querySelector("#activaterdroper55f")
var drper0= document.querySelector("#droper0")
var drper1 = document.querySelector("#droper1")
var drper2 = document.querySelector("#droper2")
var drper3 = document.querySelector("#droper3")
var drper4 = document.querySelector("#droper4")




function droper1(){
  if (q==0) {
      console.log(q)
   
   activater5f.style.transform = "translate(-1650%,-160%)";
  

   setTimeout(function () {
     drper0.style.visibility = "visible";
     drper0.style.transform ="translate(0%,700%)"
    
    
   }, 2500)

   setTimeout(function () {
     droper1reverse()
     drper0.style.visibility = "hidden";
   
   }, 3000);
 
   
 }

 function droper1reverse() {
   drper0.style.visibility = "hidden";
  
   activater5f.style.transform = "translate(0%,-0%)";
   update()
   q +=1 ;
 }
}
function droper2(){
  if (q==1) {
      console.log(q)
   
   activater5f.style.transform = "translate(-1300%,-160%)";
  

   setTimeout(function () {
     drper1.style.visibility = "visible";
     drper1.style.transform ="translate(0%,700%)"
    
    
   }, 2500)

   setTimeout(function () {
     droper2reverse()
     drper1.style.visibility = "hidden";
   
   }, 3000);
 
   
 }

 function droper2reverse() {
   drper1.style.visibility = "hidden";
  
   activater5f.style.transform = "translate(0%,-0%)";
   update()
   q +=1 ;
 }
}
function droper3(){
  if (q==2) {
      console.log(q)
   
   activater5f.style.transform = "translate(-1000%,-160%)";
  

   setTimeout(function () {
     drper2.style.visibility = "visible";
     drper2.style.transform ="translate(0%,700%)"
    
    
   }, 2500)

   setTimeout(function () {
     droper3reverse()
     drper2.style.visibility = "hidden";
   
   }, 3000);
 
   
 }

 function droper3reverse() {
   drper2.style.visibility = "hidden";
  
   activater5f.style.transform = "translate(0%,-0%)";
   update()
   q +=1 ;
 }
}

function droper4(){
  if (q==3) {
      console.log(q)
   
   activater5f.style.transform = "translate(-700%,-160%)";
  

   setTimeout(function () {
     drper3.style.visibility = "visible";
     drper3.style.transform ="translate(0%,700%)"
    
    
   }, 2500)

   setTimeout(function () {
     droper4reverse()
     drper3.style.visibility = "hidden";
   
   }, 3000);
 
   
 }

 function droper4reverse() {
   drper3.style.visibility = "hidden";
  
   activater5f.style.transform = "translate(0%,-0%)";
   update()
   q+= 1 ;
 }
}

function droper5(){
  if (q==4) {
      console.log(q)
   
   activater5f.style.transform = "translate(-400%,-160%)";
  

   setTimeout(function () {
     drper4.style.visibility = "visible";
     drper4.style.transform ="translate(0%,700%)"
    
    
   }, 2500)

   setTimeout(function () {
     droper5reverse()
     drper4.style.visibility = "hidden";
   
   }, 3000);
 
   
 }

 function droper5reverse() {
   drper4.style.visibility = "hidden";
  
   activater5f.style.transform = "translate(0%,-0%)";
   update()
   q +=1 ;
   pag=4;
 }
}
/********************************taitration5**************************8 */
var p ;
var pf1 = document.querySelector("#p1")
var pf2 = document.querySelector("#p2")
var pf3 = document.querySelector("#p3")
var pf4 = document.querySelector("#p4")
var pf5 = document.querySelector("#p5")
var orglflask = document.querySelector("#f1");
var aq2= document.querySelector("#f2")
var aq3=document.querySelector("#f3")
var aq4=document.querySelector("#f4")
var aq5v=document.querySelector("#f5v")
var drpt = document.querySelector("#droptaitration")
var vol1=document.querySelector("#vol1")
var arrowbule2 =document.querySelector("#arrowblue2")
var arrowbule1 =document.querySelector("#arrowblue1")

function ti1() {
  if (p== 0) {
    console.log(s);
    orglflask.style.transform = "translate(880%,0%) ";
     vol1.innerHTML ="10";
     ireading1.innerHTML="0";
     update()
  }
p=1
  
}

function titrate5f() {
  if (p == 1) {
    drpt.style.visibility = "visible"
    drpt.style.transform = "translate(0%,700%) ";

   setTimeout(() => {
      drpt.style.visibility = "hidden"
     
    }, 200);
   
    setTimeout(() => {
       drpt.style.transform = "translate(0%,0%)"
      
     }, 1000);
     

     
    p=2;

    

  }
  else if(p==2){
    drpt.style.visibility = "visible"
    drpt.style.transform = "translate(0%,700%) ";

   setTimeout(() => {
      drpt.style.visibility = "hidden"
     
    }, 200);
   
    setTimeout(() => {
       drpt.style.transform = "translate(0%,0%)"
      
     }, 1000);
     setTimeout(() => {
      pf1.style.opacity = "20%"
      pf1.style.opacity = "60%"
      pf1.style.opacity = "100%"
      orglflask.style.visibility = "hidden";
      update()

   }, 2500);

    
    p=3;
   

  }
  else if (p == 5) {
    drpt.style.visibility = "visible"
    drpt.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt.style.visibility = "hidden"

    }, 200);

    setTimeout(() => {
       drpt.style.transform = "translate(0%,0%)"
     }, 1000);

    p=6;

   

  }
  else if(p==6){
    drpt.style.visibility = "visible"
    drpt.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt.style.visibility = "hidden"

    }, 200);

    setTimeout(() => {
       drpt.style.transform = "translate(0%,0%)"
     }, 1000);

    setTimeout(() => {
      pf2.style.opacity = "20%"
      pf2.style.opacity = "60%"
      pf2.style.opacity = "100%"
      aq2.style.visibility = "hidden";
      update()

    }, 2500);
    p=7;

  }
  else if (p == 9) {
    drpt.style.visibility = "visible"
    drpt.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt.style.visibility = "hidden"

    }, 200);

    setTimeout(() => {
       drpt.style.transform = "translate(0%,0%)"
     }, 1000);

   p=10

  }
  else if(p==10){
    drpt.style.visibility = "visible"
    drpt.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt.style.visibility = "hidden"

    }, 200);

    setTimeout(() => {
       drpt.style.transform = "translate(0%,0%)"
     }, 1000);

    setTimeout(() => {
      pf3.style.opacity = "20%"
      pf3.style.opacity = "60%"
      pf3.style.opacity = "100%"
      aq3.style.visibility = "hidden";
      update()
     
      

    }, 2500);
    p=11;

  }
  else if (p == 13) {
    drpt.style.visibility = "visible"
    drpt.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt.style.visibility = "hidden"

    }, 200);

    setTimeout(() => {
       drpt.style.transform = "translate(0%,0%)"
     }, 1000);

    p=14;

   

  }
  else if(p==14){
    drpt.style.visibility = "visible"
    drpt.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt.style.visibility = "hidden"

    }, 200);

    setTimeout(() => {
       drpt.style.transform = "translate(0%,0%)"
     }, 1000);

    setTimeout(() => {
      pf4.style.opacity = "20%"
      pf4.style.opacity = "60%"
      pf4.style.opacity = "100%"
      aq4.style.visibility = "hidden";
      update()

    }, 2500);
    p=15;

  }
  
  
  else if (p == 17) {
    drpt.style.visibility = "visible"
    drpt.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt.style.visibility = "hidden"

    }, 200);

    setTimeout(() => {
       drpt.style.transform = "translate(0%,0%)"
     }, 1000);

    p=18;

   

  }
  else if(p==18){
    drpt.style.visibility = "visible"
    drpt.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt.style.visibility = "hidden"

    }, 200);

    setTimeout(() => {
       drpt.style.transform = "translate(0%,0%)"
     }, 1000);

    setTimeout(() => {
      pf5.style.opacity = "20%"
      pf5.style.opacity = "60%"
      pf5.style.opacity = "100%"
      aq5v.style.visibility = "hidden";
      update()

    }, 2500);
    p=19;

  }
  
  

}
function pi1(){
  if(p==3){
    pf1.style.transform = "translate(-880%,0%)";
  freading1.innerHTML="41";
   total1.innerHTML="41";
   Strength1.innerHTML="0.197";
   update()
    p=4;
  }
}
function pi2(){
  if(p==7){
    pf2.style.transform = "translate(-740%,0%)";
  freading2.innerHTML="	18.9	"
  total2.innerHTML="18.9"
  Strength2.innerHTML="0.091"
    update()
    p=8
  }
}
function pi3(){
  if(p==11){
    pf3.style.transform = "translate(-595%,0%)";
    freading3.innerHTML="	10.9	"
    total3.innerHTML="10.9"
    Strength3.innerHTML="0.052"
    update()
   
    p=12
    
  }
}
function pi4(){
  if(p==15){
    pf4.style.transform = "translate(-457%,0%)";
    freading4.innerHTML="	8.9	"
     total4.innerHTML="8.9"
     Strength4.innerHTML="0.043"
    update()
 
    p=16;
    
  }
}
function pi5(){
  if(p==19){
    pf5.style.transform = "translate(-320%,0%)";
   freading5.innerHTML="5.5	"
    total5.innerHTML="5.5"
    Strength5.innerHTML="0.026"
    update()
    pag=5;
    
    
  }
}





function ti2() {
  if (p== 4) {
    aq2.style.transform = "translate(750%,0%) ";
    
    vol2.innerHTML="10"
    ireading2.innerHTML="0"
    update()
    p=5;

  }

}


function ti3() {
  if (p == 8) {
    aq3.style.transform = "translate(593%,0%) ";
    
    vol3.innerHTML="10"
    ireading3.innerHTML="0"
 update()
 
p=9;
  }

}
function ti4() {
  if (p== 12) {
    aq4.style.transform = "translate(457%,0%) ";
    
    vol4.innerHTML="10"
    ireading4.innerHTML="0"
    update()
    p=13;

  }

}
function ti5v() {
  if (p== 16) {
    console.log(9)
    aq5v.style.transform = "translate(320%,0%) ";
    
    vol5.innerHTML="10"
    ireading5.innerHTML="0"
    update()
    p=17;

  }

}




 /**********************************step5 weing charcole************************************* */
 var kw1=document.querySelector("#wk1")
 var kw2=document.querySelector("#wk2")
 var kw3=document.querySelector("#wk3")
 var kw4=document.querySelector("#wk4")
 var kw5=document.querySelector("#wk5")
 var num=document.querySelector("#number")
var bowl11=document.querySelector("#bowl1")
var bowl22=document.querySelector("#bowl2")
var but=document.querySelector("#on")
var tare=document.querySelector("#tare")
var spoon1=document.querySelector("#spoonempty")
var spoon2=document.querySelector("#spoonfill")
var bowlcharole=document.querySelector("#charcole1")
var bowlcharole2=document.querySelector("#charcole2")
var bowlcharole3=document.querySelector("#charcole3")
var charcolemove=document.querySelector("#movecharcole")
var charcolefill=document.querySelector("#fillcharcole")
var charcolefill2=document.querySelector("#fillcharcole2")
var bekarcharcoleee1=document.querySelector("#beakercharcole1")
var bekarcharcoleee2=document.querySelector("#beakercharcole2")
var bekarcharcoleee3=document.querySelector("#beakercharcole3")
var bekarcharcoleee4=document.querySelector("#beakercharcole4")
var bekarcharcoleee5=document.querySelector("#beakercharcole5")
var beaker11=document.querySelector("#beaker1")
var beaker22=document.querySelector("#beaker2")
var beaker33=document.querySelector("#beaker3")
var beaker44=document.querySelector("#beaker4")
var beaker55=document.querySelector("#beaker5")
var weingmachine=document.querySelector("#weingmachine")
var m;
function onbutton(){
    if(m==1){
        num.style.visibility="visible";
        update()
    }
    m+=1;   
}
function bowlput(){
    if(m==2){
     
        bowl11.style.transform="translate(-116%,-100%)";
        bowl11.style.transform="translate(-230%,-250%)";
        charcolefill2.style.visibility="visible"
        charcolefill.style.visibility="visible"
        charcolefill2.style.opacity="100%"         
        charcolefill.style.opacity="100%"  
       
        setTimeout(function(){
            num.innerHTML="5gm";
            update()
         

        },2200)  
        m+=1;
    
      

    }
    else if(m==6){
        
        bowl11.style.transform="translate(150%, -800%) "
        charcolefill2.style.transform="translate(90%, -1340%)"
        charcolefill.style.transform="translate(90%, -1320%) "
        num.innerHTML="0.0gm";

        
        setTimeout(function(){
          bowl11.style.transform=" translate(150%, -800%) rotate(45deg)"
          charcolefill2.style.transform="translate(200%, -1000%) rotate(45deg)"
          charcolefill.style.transform="translate(200%, -1000%)rotate(45deg) "
        },1200)
        setTimeout(function(){
            bowl11.style.transform=" rotate(0deg)"
          charcolefill2.style.transform="translate(200%, -200%) rotate(45deg)"
          charcolefill.style.transform="translate(200%, -200%)rotate(45deg) "
        
        },1900)
        setTimeout(function(){
                    charcolefill2.style.opacity="0%"
                  
                    charcolefill.style.opacity="0%"
                    bekarcharcoleee1.style.visibility="visible";
          
        },2200)
        setTimeout(function(){
          
          bekarcharcoleee1.style.opacity="100%"
          
          
          bowl11.style.transform="translate(0%, 0%) rotate(0deg)"
           },3000)
     
    
       setTimeout(function()  {
     
        charcolefill.style.transform="translate(0%, 0%) rotate(0deg)"
        charcolefill2.style.transform="translate(0%, 0%) rotate(0deg)"
        bowlcharole3.style.visibility="visible"
        update()
     
       },4000);
       m+=1

    }
    else if(m==7){
        bowl11.style.transform="translate(-116%,-100%)";
        bowl11.style.transform="translate(-230%,-250%)";
        charcolefill2.style.visibility="visible"
        charcolefill.style.visibility="visible"
        charcolefill2.style.opacity="100%"         
        charcolefill.style.opacity="100%"  
       
        setTimeout(function(){
            num.innerHTML="5gm";
            update()
        },2200)  
        m+=1;
    }
    else if(m==11){
        bowl11.style.transform="translate(280%, -800%) "
        charcolefill2.style.transform="translate(420%, -1340%)"
        charcolefill.style.transform="translate(420%, -1320%) "
        num.innerHTML="0.0gm";
        setTimeout(function(){
          bowl11.style.transform=" translate(280%, -800%) rotate(45deg)"
          charcolefill2.style.transform="translate(610%, -1000%) rotate(45deg)"
          charcolefill.style.transform="translate(610%, -1000%)rotate(45deg) "
        },1200)
        setTimeout(function(){
            bowl11.style.transform=" rotate(0deg)"
          charcolefill2.style.transform="translate(610%, -200%) rotate(45deg)"
          charcolefill.style.transform="translate(610%, -200%)rotate(45deg) "
        
        },1900)
        setTimeout(function(){
                    charcolefill2.style.opacity="0%"
                    bekarcharcoleee2.style.visibility="visible";
                    charcolefill.style.opacity="0%"
          
        },2200)
        setTimeout(function(){
          
          bekarcharcoleee2.style.opacity="100%"
          
          bowl11.style.transform="translate(0%, 0%) rotate(0deg)"
           },3000)
    
       setTimeout(function()  {
        charcolefill.style.transform="translate(0%, 0%) rotate(0deg)"
        charcolefill2.style.transform="translate(0%, 0%) rotate(0deg)"
        bowlcharole3.style.visibility="visible"
        update()
   
       },4000);
       m+=1

    }
    else if(m==12){
        bowl11.style.transform="translate(-116%,-100%)";
        bowl11.style.transform="translate(-230%,-250%)";
        charcolefill2.style.visibility="visible"
        charcolefill.style.visibility="visible"
        charcolefill2.style.opacity="100%"         
        charcolefill.style.opacity="100%"  
       
        setTimeout(function(){
            num.innerHTML="5gm";
            update()
        },2200)  
        m+=1;
    }
    else if(m==16){
        bowl11.style.transform="translate(410%, -800%) "
        charcolefill2.style.transform="translate(780%, -1340%)"
        charcolefill.style.transform="translate(780%, -1320%) "
        num.innerHTML="0.0gm";
        setTimeout(function(){
          bowl11.style.transform=" translate(410%, -800%) rotate(45deg)"
          charcolefill2.style.transform="translate(1070%, -1000%) rotate(45deg)"
          charcolefill.style.transform="translate(1070%, -1000%)rotate(45deg) "
        },1200)
        setTimeout(function(){
            bowl11.style.transform=" rotate(0deg)"
          charcolefill2.style.transform="translate(1070%, -200%) rotate(45deg)"
          charcolefill.style.transform="translate(1070%, -200%)rotate(45deg) "
        
        },1900)
        setTimeout(function(){
                    charcolefill2.style.opacity="0%"
                    bekarcharcoleee3.style.visibility="visible";
                    charcolefill.style.opacity="0%"
          
        },2200)
        setTimeout(function(){
          
          bekarcharcoleee3.style.opacity="100%"
          
          bowl11.style.transform="translate(0%, 0%) rotate(0deg)"
           },3000)
    
       setTimeout(function()  {
        charcolefill.style.transform="translate(0%, 0%) rotate(0deg)"
        charcolefill2.style.transform="translate(0%, 0%) rotate(0deg)"
        bowlcharole3.style.visibility="visible"
        update()
   
       },4000);
       m+=1


    }
    else if(m==17){
        bowl11.style.transform="translate(-116%,-100%)";
        bowl11.style.transform="translate(-230%,-250%)";
        charcolefill2.style.visibility="visible"
        charcolefill.style.visibility="visible"
        charcolefill2.style.opacity="100%"         
        charcolefill.style.opacity="100%"  
       
        setTimeout(function(){
            num.innerHTML="5gm";
            update()
        },2200)  
        m+=1;
    }
    else if(m==21){
        bowl11.style.transform="translate(540%, -800%) "
        charcolefill2.style.transform="translate(1180%, -1340%)"
        charcolefill.style.transform="translate(1180%, -1320%) "
        num.innerHTML="0.0gm";
        setTimeout(function(){
            bowl11.style.transform="translate(540%, -800%)rotate(45deg) "
          charcolefill2.style.transform="translate(1430%, -1000%) rotate(45deg)"
          charcolefill.style.transform="translate(1430%, -1000%)rotate(45deg) "
        },1200)
        setTimeout(function(){
            bowl11.style.transform=" rotate(0deg)"
          charcolefill2.style.transform="translate(1430%, -200%) rotate(45deg)"
          charcolefill.style.transform="translate(1430%, -200%)rotate(45deg) "
        
        },1900)
        setTimeout(function(){
                    charcolefill2.style.opacity="0%"
                    bekarcharcoleee4.style.visibility="visible";
                    charcolefill.style.opacity="0%"
          
        },2200)
        setTimeout(function(){
          
          bekarcharcoleee4.style.opacity="100%"
          
          bowl11.style.transform="translate(0%, 0%) rotate(0deg)"
           },3000)
    
       setTimeout(function()  {
        charcolefill.style.transform="translate(0%, 0%) rotate(0deg)"
        charcolefill2.style.transform="translate(0%, 0%) rotate(0deg)"
        bowlcharole3.style.visibility="visible"
        update()
       },4000);
       m+=1


    }
    else if(m==22){
        bowl11.style.transform="translate(-116%,-100%)";
        bowl11.style.transform="translate(-230%,-250%)";
        charcolefill2.style.visibility="visible"
        charcolefill.style.visibility="visible"
        charcolefill2.style.opacity="100%"         
        charcolefill.style.opacity="100%"  
       
        setTimeout(function(){
            num.innerHTML="5gm";
            update()
        },2200)  
        m+=1;
    }
    else if(m==26){
        bowl11.style.transform="translate(670%, -800%) "
        charcolefill2.style.transform="translate(1570%, -1340%)"
        charcolefill.style.transform="translate(1570%, -1320%) "
        num.innerHTML="0.0gm";
        setTimeout(function(){
          bowl11.style.transform=" translate(670%, -800%) rotate(45deg)"
          charcolefill2.style.transform="translate(1850%, -1000%) rotate(45deg)"
          charcolefill.style.transform="translate(1850%, -1000%)rotate(45deg) "
        },1200)
        setTimeout(function(){
            bowl11.style.transform=" rotate(0deg)"
          charcolefill2.style.transform="translate(1850%, -200%) rotate(45deg)"
          charcolefill.style.transform="translate(1850%, -200%)rotate(45deg) "
        
        },1900)
        setTimeout(function(){
                    charcolefill2.style.opacity="0%"
                   
                    bekarcharcoleee5.style.visibility="visible";
                    charcolefill.style.opacity="0%"
          
        },2200)
        setTimeout(function(){
          
          bekarcharcoleee5.style.opacity="100%"
          
          bowl11.style.transform="translate(0%, 0%) rotate(0deg)"
           },3000)
    
       setTimeout(function()  {
        charcolefill.style.transform="translate(0%, 0%) rotate(0deg)"
        charcolefill2.style.transform="translate(0%, 0%) rotate(0deg)"
        bowlcharole3.style.visibility="visible"
        update()
   
       },4000);
       m+=1

     pag=6;
    }
}
function tarebutton(){
    if(m==3){
        num.innerHTML="0.0gm";
        update()  
        m+=1;
       

    }
    else if(m==8){
        num.innerHTML="0.0gm";
        update()  
        m+=1;
       

    }
    else if(m==13){
        num.innerHTML="0.0gm";  
        update()
        m+=1;
       

    }
    else if(m==18){
        num.innerHTML="0.0gm";  
        update()
        m+=1;
      

    }
    else if(m==23){
        num.innerHTML="0.0gm";
        update()  
        m+=1;
        
        

    }
}
spoon1.style.transform="rotate(40deg)";
function spoonput(){
    if(m==4){
       
        spoon1.style.transform="translate(-160%,-80%) rotate(0deg)";
        setTimeout(function(){
            bowlcharole3.style.visibility="hidden"
            bowlcharole.style.visibility="visible"; 
            spoon1.style.transform="translate(-520%,-138%) rotate(0deg)";
            charcolefill.style.transform="translate(-1100%,-320%) ";
            setTimeout(function(){
                  num.innerHTML="0.05gm";
            },1700)

        },1200)
        setTimeout(function(){
            spoon1.style.transform="translate(0%,0%) rotate(40deg)"
            update()
        },4500)
        m+=1;
      
    }
    else if(m==5){
      spoon1.style.transform="translate(-160%,-80%) rotate(0deg)";
        setTimeout(function(){
            bowlcharole.style.visibility="hidden"
            bowlcharole2.style.visibility="visible"; 
            spoon1.style.transform="translate(-520%,-138%) rotate(0deg)";
            charcolefill2.style.transform="translate(-1100%,-370%) ";
            setTimeout(function(){
                  num.innerHTML="1gm";
                },1700)

            },1200)
            setTimeout(function(){
            spoon1.style.transform="translate(0%,0%) rotate(40deg)"
            update()
        },4500)
        m+=1;
    }
    else if(m==9){
        spoon1.style.transform="translate(-160%,-80%) rotate(0deg)";
        setTimeout(function(){
            bowlcharole3.style.visibility="hidden"
            bowlcharole.style.visibility="visible"; 
            spoon1.style.transform="translate(-520%,-138%) rotate(0deg)";
            charcolefill.style.transform="translate(-1100%,-320%) ";
            setTimeout(function(){
                  num.innerHTML="0.05gm";
            },1700)

        },1200)
        setTimeout(function(){
            spoon1.style.transform="translate(0%,0%) rotate(40deg)"
            update()
        },4500)
        m+=1;
    }
    else if(m==10){
        spoon1.style.transform="translate(-160%,-80%) rotate(0deg)";
        setTimeout(function(){
            bowlcharole.style.visibility="hidden"
            bowlcharole2.style.visibility="visible"; 
            spoon1.style.transform="translate(-520%,-138%) rotate(0deg)";
            charcolefill2.style.transform="translate(-1100%,-370%) ";
            setTimeout(function(){
                  num.innerHTML="1gm";
                },1700)

            },1200)
            setTimeout(function(){
            spoon1.style.transform="translate(0%,0%) rotate(40deg)"
            update()
        },4500)
        m+=1;
    }
    else if(m==14){
        spoon1.style.transform="translate(-160%,-80%) rotate(0deg)";
        setTimeout(function(){
            bowlcharole3.style.visibility="hidden"
            bowlcharole.style.visibility="visible"; 
            spoon1.style.transform="translate(-520%,-138%) rotate(0deg)";
            charcolefill.style.transform="translate(-1100%,-320%) ";
            setTimeout(function(){
                  num.innerHTML="0.05gm";
            },1700)

        },1200)
        setTimeout(function(){
            spoon1.style.transform="translate(0%,0%) rotate(40deg)"
            update()
        },4500)
        m+=1;
    }
    else if(m==15){
        spoon1.style.transform="translate(-160%,-80%) rotate(0deg)";
        setTimeout(function(){
            bowlcharole.style.visibility="hidden"
            bowlcharole2.style.visibility="visible"; 
            spoon1.style.transform="translate(-520%,-138%) rotate(0deg)";
            charcolefill2.style.transform="translate(-1100%,-370%) ";
            setTimeout(function(){
                  num.innerHTML="1gm";
                },1700)

            },1200)
            setTimeout(function(){
            spoon1.style.transform="translate(0%,0%) rotate(40deg)"
            update()
        },4500)
        m+=1;
    }
    else if(m==19){
        spoon1.style.transform="translate(-160%,-80%) rotate(0deg)";
        setTimeout(function(){
            bowlcharole3.style.visibility="hidden"
            bowlcharole.style.visibility="visible"; 
            spoon1.style.transform="translate(-520%,-138%) rotate(0deg)";
            charcolefill.style.transform="translate(-1100%,-320%) ";
            setTimeout(function(){
                  num.innerHTML="0.05gm";
            },1700)

        },1200)
        setTimeout(function(){
            spoon1.style.transform="translate(0%,0%) rotate(40deg)"
            update()
        },4500)
        m+=1;
    }
    else if(m==20){
        spoon1.style.transform="translate(-160%,-80%) rotate(0deg)";
        setTimeout(function(){
            bowlcharole.style.visibility="hidden"
            bowlcharole2.style.visibility="visible"; 
            spoon1.style.transform="translate(-520%,-138%) rotate(0deg)";
            charcolefill2.style.transform="translate(-1100%,-370%) ";
            setTimeout(function(){
                  num.innerHTML="1gm";
                },1700)

            },1200)
            setTimeout(function(){
            spoon1.style.transform="translate(0%,0%) rotate(40deg)"
            update()
        },4500)
        m+=1;
    }
    else if(m==24){
        spoon1.style.transform="translate(-160%,-80%) rotate(0deg)";
        setTimeout(function(){
            bowlcharole3.style.visibility="hidden"
            bowlcharole.style.visibility="visible"; 
            spoon1.style.transform="translate(-520%,-138%) rotate(0deg)";
            charcolefill.style.transform="translate(-1100%,-320%) ";
            setTimeout(function(){
                  num.innerHTML="0.05gm";
            },1700)

        },1200)
        setTimeout(function(){
            spoon1.style.transform="translate(0%,0%) rotate(40deg)"
            update()
        },4500)
        m+=1;
    }
    else if(m==25){
        spoon1.style.transform="translate(-160%,-80%) rotate(0deg)";
        setTimeout(function(){
            bowlcharole.style.visibility="hidden"
            bowlcharole2.style.visibility="visible"; 
            spoon1.style.transform="translate(-520%,-138%) rotate(0deg)";
            charcolefill2.style.transform="translate(-1100%,-370%) ";
            setTimeout(function(){
                  num.innerHTML="1gm";
                },1700)

            },1200)
            setTimeout(function(){
            spoon1.style.transform="translate(0%,0%) rotate(40deg)"
            update()
        },4500)
        m+=1;
    }

}
/***********************************step5 magnetic machine******************************************* */
var u ;
var mkk1=document.querySelector("#kk1")
var mkk2=document.querySelector("#kk2")
var mkk3=document.querySelector("#kk3")
var mkk4=document.querySelector("#kk4")
var mkk5=document.querySelector("#kk5")

var solb1 = document.querySelector("#black11")
var solb2 = document.querySelector("#black22")
var solb3 = document.querySelector("#black33")
var solb4 = document.querySelector("#black44")
var solb5 = document.querySelector("#black55")

var solbfi1 = document.querySelector("#blackfi1")
var solbfi2 = document.querySelector("#blackfi2")
var solbfi3 = document.querySelector("#blackfi3")
var solbfi4 = document.querySelector("#blackfi4")
var solbfi5 = document.querySelector("#blackfi5")
var buttonvisibe = document.querySelector("#red")
var buttonvisibeoff = document.querySelector("#blue")
var arrowvisible = document.querySelector("#arrow")
var arrowvisible0 = document.querySelector("#arrow0")
var arrowvisible1 = document.querySelector("#arrow1")
var rotatespeed = document.querySelector("#buttonspeed")
var meg = document.querySelector("#megnatic")
var meg1 = document.querySelector("#meg1")
var meg2 = document.querySelector("#meg2")
var meg3 = document.querySelector("#meg3")
var meg4 = document.querySelector("#meg4")
var meg5 = document.querySelector("#meg5")
var onmain = document.querySelector("#powerbuttonon")
var offmain = document.querySelector("#powerbuttonoff")
var offmach = document.querySelector("#machbuttonoff")
var onmach = document.querySelector("#machbuttonon")
var hand = document.querySelector("#hand")
var redlight = document.querySelector("#redlight")
var nobspeed = document.querySelector("#nobspeed")
var nobheat = document.querySelector("#nobheat")
var kk1=document.querySelector("kk1")
var kk2=document.querySelector("kk2")
var kk3=document.querySelector("kk3")
var kk4=document.querySelector("kk4")
var kk5=document.querySelector("kk5")



// hand.style.visibility = "visible";
hand.style.transform = "translate(-470%,-400%) rotate(90deg)"


function mainon() {
  if (u == 0) {
    hand.style.visibility = "visible";
    hand.style.transform = "translate(-460%,-880%)rotate(-180deg)"
    offmain.style.visibility = "hidden";
    onmain.style.visibility = "visible";
    redlight.style.visibility = "visible";
  //   setTimeout(function(){
  //     // kk1.style.visibility="visible"
  //     // kk2.style.visibility="visible"
  //     // kk3.style.visibility="visible"
  //     // kk4.style.visibility="visible"
  //     // kk5.style.visibility="visible"
  // },1000)
    update()
  }
  u += 1;
}

function machon() {
  if (u == 1) {

    offmach.style.visibility = "hidden";
    onmach.style.visibility = "visible";
    // screen.style.visibility="visible";
    hand.style.visibility = "visible";
    hand.style.transform = "translate(-760%,-880%)rotate(-180deg)"
    update()
  }
  u += 1;
}

function black1() {
  if (u == 2) {
    console.log(u);
    solb1.style.transform = "translate(-580%,-85%)";
    hand.style.visibility = "visible";
    hand.style.transform = "translate(-860%,-880%)rotate(-180deg)"
    update()
    u += 1;
  }
}
function black2() {
  if (u == 3) {
    console.log(u);
    solb2.style.transform = "translate(-590%,-85%)";
    update()
   // hand.style.visibility = "visible";
   // hand.style.transform = "translate(-960%,-880%)rotate(-180deg)"
  }
  u += 1;
}
function black3() {
  if (u == 4) {
    console.log(u);
    solb3.style.transform = "translate(-600%,-85%)";
    hand.style.visibility = "visible";
    hand.style.transform = "translate(-1050%,-880%)rotate(-180deg)"
    update()
  }
  u += 1;
}
function black4() {
  if (u == 5) {
    console.log(u);
    solb4.style.transform = "translate(-610%,-85%)";
    hand.style.visibility = "visible";
    hand.style.transform = "translate(-1150%,-880%)rotate(-180deg)"
    update()
  }
  u += 1;
}
function black5() {
  if (u == 6) {
    console.log(u);
    solb5.style.transform = "translate(-620%,-85%)";
    hand.style.visibility = "visible";
    hand.style.transform = "translate(-1150%,-850%)rotate(90deg)"
    setTimeout(function(){
      mkk1.style.visibility="hidden"
      mkk2.style.visibility="hidden"
      mkk3.style.visibility="hidden"
      mkk4.style.visibility="hidden"
      mkk5.style.visibility="hidden"
  },1000)
    update()

  }
  u =7;
}
function putmeg() {
  if (u == 7) {
    meg.style.visibility = "hidden"
    meg1.style.visibility = "visible"
    meg1.style.transform = "translate(0%,2000%)"
    meg2.style.visibility = "visible"
    meg2.style.transform = "translate(0%,2000%)"
    meg3.style.visibility = "visible"
    meg3.style.transform = "translate(0%,2000%)"
    meg4.style.visibility = "visible"
    meg4.style.transform = "translate(0%,2000%)"
    meg5.style.visibility = "visible"
    meg5.style.transform = "translate(0%,2000%)"
    hand.style.visibility = "visible";
    hand.style.transform = "translate(-560%,-880%)rotate(-180deg)"
    update()
  }
  u=8;
}
function nobhon() {
  if (u == 8) {
    console.log(u);
    nobheat.style.rotate = "-100deg";
    hand.style.visibility = "visible";
    hand.style.transform = "translate(-290%,-880%)rotate(-180deg)"
    update()
    

  }
  u = 9;
}
function nobson() {
  if (u == 9) {
    console.log(u);

    nobspeed.style.rotate = "-30deg";
    
          

      
        setTimeout(() => {
          solbfi1.style.visibility="visible"
          solbfi2.style.visibility="visible"
          solbfi3.style.visibility = "visible"
          solbfi4.style.visibility="visible"
          solbfi5.style.visibility="visible"

          solb1.style.visibility = "hidden"
          solb2.style.visibility = "hidden"
          solb3.style.visibility = "hidden"
          solb4.style.visibility = "hidden"
          solb5.style.visibility = "hidden"
          update()

        }, 1900);
      

  }
  pag=7;
  u += 1;
}
/********************************filter******************************************************* */


var uk ;
var filter1 = document.querySelector("#bflask11")
var filter2 = document.querySelector("#bflask22")
var filter3 = document.querySelector("#bflask33")
var filter4 = document.querySelector("#bflask44")
var filter5 = document.querySelector("#bflask55")
var blackdrp = document.querySelector("#bdrop11")
var bldrp11 =document.querySelector("#bldrpflask11")
var drop = document.querySelector("#drop11")
var filterdrp = document.querySelector("#fdrop11")
var ready = document.querySelector("#readyflask11")
var acflask1 = document.querySelector("#aceticflask11")
var acflask2 = document.querySelector("#aceticflask22")
var acflask3 = document.querySelector("#aceticflask33")
var acflask4 = document.querySelector("#aceticflask44")
var acflask5 = document.querySelector("#aceticflask55")
var blanck11 =document.querySelector("#blanckflask11")



function bflask1() {
  if (uk == 0) {
    console.log(u);
    filter1.style.transform = "translate(-200%,-200%) rotate(-80deg)";




    setTimeout(() => {
      bldrp11.style.visibility="visible"
      

    }, 900);
    setTimeout(() => {
      blackdrp.style.visibility = "visible"
      blanck11.style.visibility ="visible"
      filter1.style.opacity = "0%"
      bldrp11.style.visibility="hidden"
      blanck11.style.visibility ="hidden"
    
    }, 1200);

    setTimeout(() => {
      blackdrp.style.visibility = "hidden"
    }, 1900);
    setTimeout(()=>{
      drop.style.visibility = "hidden"
      drop.style.transform = "translate(0%,500%)"
    },2300);
    setTimeout(()=>{
    ready.style.visibility = "hidden"
      acflask1.style.visibility = "visible"
    },2800)
    setTimeout(() => {
      drop.style.visibility = "hidden"

    }, 1700);
    setTimeout(() => {
      drop.style.transform = "translate(0%,0%)"
    }, 1800);

    setTimeout(() => {
      filter1.style.opacity = "0%"
      update()
    }, 2000);
  }

}
function aceticflask1() {

  acflask1.style.transform = "translate(280%,0%)";

  uk+= 1;
  update()
}

function bflask2() {
  if (uk == 1) {
    console.log(u);
    filter2.style.transform = "translate(-310%,-200%) rotate(-80deg)";
    ready.style.visibility = "visible"



    setTimeout(() => {
      bldrp11.style.visibility="visible"
      

    }, 900);
    setTimeout(() => {
      blackdrp.style.visibility = "visible"
      blanck11.style.visibility ="visible"
      filter2.style.opacity = "0%"
      bldrp11.style.visibility="hidden"
      blanck11.style.visibility ="hidden"
    
    }, 1200);

    setTimeout(() => {
      blackdrp.style.visibility = "hidden"
    }, 1900);
    setTimeout(()=>{
      drop.style.visibility = "visible"
      drop.style.transform = "translate(0%,500%)"
    },2300);
    setTimeout(()=>{
    ready.style.visibility = "hidden"
      acflask2.style.visibility = "visible"
    },2800)
    setTimeout(() => {
      drop.style.visibility = "hidden"

    }, 1700);
    setTimeout(() => {
      drop.style.transform = "translate(0%,0%)"
    }, 1800);

    setTimeout(() => {
      filter2.style.opacity = "0%"
      update()
    }, 2000);
  }

}
function aceticflask2() {

  acflask2.style.transform = "translate(390%,0%)";
  update()
  uk+= 1;
}

function bflask3() {
  if (uk == 2) {
    console.log(u);
    filter3.style.transform = "translate(-430%,-200%) rotate(-80deg)";
    ready.style.visibility = "visible"



    setTimeout(() => {
      bldrp11.style.visibility="visible"
      

    }, 900);
    setTimeout(() => {
      blackdrp.style.visibility = "visible"
      blanck11.style.visibility ="visible"
      filter3.style.opacity = "0%"
      bldrp11.style.visibility="hidden"
      blanck11.style.visibility ="hidden"
    
    }, 1200);

    setTimeout(() => {
      blackdrp.style.visibility = "hidden"
    }, 1900);
    setTimeout(()=>{
      drop.style.visibility = "visible"
      drop.style.transform = "translate(0%,500%)"
    },2300);
    setTimeout(()=>{
    ready.style.visibility = "hidden"
      acflask3.style.visibility = "visible"
    },2800)
    setTimeout(() => {
      drop.style.visibility = "hidden"

    }, 1700);
    setTimeout(() => {
      drop.style.transform = "translate(0%,0%)"
    }, 1800);

    setTimeout(() => {
      filter3.style.opacity = "0%"
      update()
    }, 2000);
  }

}
function aceticflask3() {

  acflask3.style.transform = "translate(500%,0%)";
  uk+= 1;
  update()
}
function bflask4() {
  if (uk == 3) {
    console.log(u);
    filter4.style.transform = "translate(-560%,-200%) rotate(-80deg)";
    ready.style.visibility = "visible"



    setTimeout(() => {
      bldrp11.style.visibility="visible"
      

    }, 900);
    setTimeout(() => {
      blackdrp.style.visibility = "visible"
      blanck11.style.visibility ="visible"
      filter4.style.opacity = "0%"
      bldrp11.style.visibility="hidden"
      blanck11.style.visibility ="hidden"
    
    }, 1200);

    setTimeout(() => {
      blackdrp.style.visibility = "hidden"
    }, 1900);
    setTimeout(()=>{
      drop.style.visibility = "visible"
      drop.style.transform = "translate(0%,500%)"
    },2300);
    setTimeout(()=>{
    ready.style.visibility = "hidden"
      acflask4.style.visibility = "visible"
    },2800)
    setTimeout(() => {
      drop.style.visibility = "hidden"

    }, 1700);
    setTimeout(() => {
      drop.style.transform = "translate(0%,0%)"
    }, 1800);

    setTimeout(() => {
      filter4.style.opacity = "0%"
      update()
    }, 2000);
  }

}
function aceticflask4() {

  acflask4.style.transform = "translate(610%,0%)";
  uk+= 1;
  update()
}
function bflask5() {
  if (uk == 4) {
    console.log(u);
    filter5.style.transform = "translate(-680%,-200%) rotate(-80deg)";
    ready.style.visibility = "visible"



    setTimeout(() => {
      bldrp11.style.visibility="visible"
      

    }, 900);
    setTimeout(() => {
      blackdrp.style.visibility = "visible"
      blanck11.style.visibility ="visible"
      filter5.style.opacity = "0%"
      bldrp11.style.visibility="hidden"
      blanck11.style.visibility ="hidden"
    
    }, 1200);

    setTimeout(() => {
      blackdrp.style.visibility = "hidden"
    }, 1900);
    setTimeout(()=>{
      drop.style.visibility = "visible"
      drop.style.transform = "translate(0%,500%)"
    },2300);
    setTimeout(()=>{
    ready.style.visibility = "hidden"
      acflask5.style.visibility = "visible"
    },2800)
    setTimeout(() => {
      drop.style.visibility = "hidden"

    }, 1700);
    setTimeout(() => {
      drop.style.transform = "translate(0%,0%)"
    }, 1800);

    setTimeout(() => {
      filter5.style.opacity = "0%"
      update()
    }, 2000);
  }
  pag=8;

}
function aceticflask5() {

  acflask5.style.transform = "translate(720%,0%)";
  uk+= 1;
  update()
}


/*************************************************taitration last******************************** */

var v ;
var pf111 = document.querySelector("#p111")
var pf222 = document.querySelector("#p222")
var pf333 = document.querySelector("#p333")
var pf444 = document.querySelector("#p444")
var pf555 = document.querySelector("#p555")
var orglflask111 = document.querySelector("#f111");
var aq222= document.querySelector("#f222")
var aq333=document.querySelector("#f333")
var aq444=document.querySelector("#f444")
var aq555=document.querySelector("#f555v")
var drpt111 = document.querySelector("#droptaitration111")
var vol111=document.querySelector("#vol111")
var arrowbule222 =document.querySelector("#arrowblue222")
var arrowbule111 =document.querySelector("#arrowblue111")
var phand11=document.querySelector("#hand111")



function ti111() {
  if (v== 0) {
    console.log(s);
    orglflask111.style.transform = "translate(880%,0%) ";
    vol111.innerHTML="10";
   ireading111.innerHTML="0";
   phand11.style.visibility = "visible";
  phand11.style.transform = "translate(-1150%,-500%)rotate(90deg)"
 
     update()
  }
v=1
  
}

function titrate3rd() {
  if (v == 1) {
    drpt111.style.visibility = "visible"
    drpt111.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt111.style.visibility = "hidden"
      
    }, 200);
    
    setTimeout(() => {
       drpt111.style.transform = "translate(0%,0%)"

     }, 1000);

     
    v=2;

    

  }
  else if(v==2){
    drpt111.style.visibility = "visible"
    drpt111.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt111.style.visibility = "hidden"
      
    }, 200);
    
    setTimeout(() => {
       drpt111.style.transform = "translate(0%,0%)"

     }, 1000);
     setTimeout(() => {
      pf111.style.opacity = "20%"
      pf111.style.opacity = "60%"
      pf111.style.opacity = "100%"
      orglflask111.style.visibility = "hidden";
      update()

   }, 2500);

    
    v=3;
   

  }
  else if (v == 5) {
    drpt111.style.visibility = "visible"
    drpt111.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt111.style.visibility = "hidden"
      
    }, 200);
    
    setTimeout(() => {
       drpt111.style.transform = "translate(0%,0%)"

     }, 1000);

    v=6;

   

  }
  else if(v==6){
    drpt111.style.visibility = "visible"
    drpt111.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt111.style.visibility = "hidden"
      
    }, 200);
    
    setTimeout(() => {
       drpt111.style.transform = "translate(0%,0%)"

     }, 1000);

    setTimeout(() => {
      pf222.style.opacity = "20%"
      pf222.style.opacity = "60%"
      pf222.style.opacity = "100%"
      aq222.style.visibility = "hidden";
      update()

    }, 2500);
    v=7;

  }
  else if (v == 9) {
    drpt111.style.visibility = "visible"
    drpt111.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt111.style.visibility = "hidden"
      
    }, 200);
    
    setTimeout(() => {
       drpt111.style.transform = "translate(0%,0%)"

     }, 1000);

   v=10

  }
  else if(v==10){
    drpt111.style.visibility = "visible"
    drpt111.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt111.style.visibility = "hidden"
      
    }, 200);
    
    setTimeout(() => {
       drpt111.style.transform = "translate(0%,0%)"

     }, 1000);

    setTimeout(() => {
      pf333.style.opacity = "20%"
      pf333.style.opacity = "60%"
      pf333.style.opacity = "100%"
      aq333.style.visibility = "hidden";
      update()
     
      

    }, 2500);
    v=11;

  }
  else if (v == 13) {
    drpt111.style.visibility = "visible"
    drpt111.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt111.style.visibility = "hidden"
      
    }, 200);
    
    setTimeout(() => {
       drpt111.style.transform = "translate(0%,0%)"

     }, 1000);

    v=14;

   

  }
  else if(v==14){
    drpt111.style.visibility = "visible"
    drpt111.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt111.style.visibility = "hidden"
      
    }, 200);
    
    setTimeout(() => {
       drpt111.style.transform = "translate(0%,0%)"

     }, 1000);

    setTimeout(() => {
      pf444.style.opacity = "20%"
      pf444.style.opacity = "60%"
      pf444.style.opacity = "100%"
      aq444.style.visibility = "hidden";
      update()

    }, 2500);
    v=15;

  }
  
  
  else if (v== 17) {
    drpt111.style.visibility = "visible"
    drpt111.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt111.style.visibility = "hidden"
      
    }, 200);
    
    setTimeout(() => {
       drpt111.style.transform = "translate(0%,0%)"

     }, 1000);

    v=18;

   

  }
  else if(v==18){
    drpt111.style.visibility = "visible"
    drpt111.style.transform = "translate(0%,700%) ";

    setTimeout(() => {
      drpt111.style.visibility = "hidden"
      
    }, 200);
    
    setTimeout(() => {
       drpt111.style.transform = "translate(0%,0%)"

     }, 1000);

    setTimeout(() => {
      pf555.style.opacity = "20%"
      pf555.style.opacity = "60%"
      pf555.style.opacity = "100%"
      aq555.style.visibility = "hidden";
      update()

    }, 2500);
    v=19;

  }
  
  

}
function pi111(){
  if(v==3){
    pf111.style.transform = "translate(-880%,0%)";
  freading111.innerHTML="38.5";
  total111.innerHTML="38.5";
  Strength111.innerHTML="0.5";
  phand11.style.visibility = "visible";
  phand11.style.transform = "translate(-450%,-890%)rotate(180deg)"
   update()
    v=4;
  }
}
function pi222(){
  if(v==7){
    pf222.style.transform = "translate(-740%,0%)";
  freading222.innerHTML="	15.2	"
  total222.innerHTML="15.2"
  Strength222.innerHTML="0.336"
  phand11.style.visibility = "visible";
  phand11.style.transform = "translate(-550%,-890%)rotate(180deg)"
    update()
    v=8
  }
}
function pi333(){
  if(v==11){
    pf333.style.transform = "translate(-595%,0%)";
  freading333.innerHTML="	6.7	"
  total333.innerHTML="6.7"
  Strength333.innerHTML="0.22"
  phand11.style.visibility = "visible";
  phand11.style.transform = "translate(-700%,-890%)rotate(180deg)"
    update()
   
    v=12
    
  }
}
function pi444(){
  if(v==15){
    pf444.style.transform = "translate(-457%,0%)";
    freading444.innerHTML="	6	"
     total444.innerHTML="6"
     Strength444.innerHTML="0.125"
     phand11.style.visibility = "visible";
     phand11.style.transform = "translate(-800%,-890%)rotate(180deg)"
    update()
 
    v=16
    
  }
}
function pi555(){
  if(v==19){
    pf555.style.transform = "translate(-320%,0%)";
   freading555.innerHTML="2.5	"
    total555.innerHTML="2.5"
    Strength555.innerHTML="0.08"
    phand11.style.visibility = "hidden";
    update()
    pag=9;
   
    
    
  }
}





function ti222() {
  if (v== 4) {
    aq222.style.transform = "translate(750%,0%) ";
    phand11.style.visibility = "visible";
    phand11.style.transform = "translate(-1150%,-500%)rotate(90deg)"
    
    vol222.innerHTML="10"
    ireading222.innerHTML="0"
    update()
    v=5;

  }

}


function ti333() {
  if (v == 8) {
    aq333.style.transform = "translate(593%,0%) ";
    phand11.style.visibility = "visible";
    phand11.style.transform = "translate(-1150%,-500%)rotate(90deg)"
    
    vol333.innerHTML="10"
    ireading333.innerHTML="0"
 update()
 
v=9;
  }

}
function ti444() {
  if (v== 12) {
    aq444.style.transform = "translate(457%,0%) ";
    phand11.style.visibility = "visible";
    phand11.style.transform = "translate(-1150%,-500%)rotate(90deg)"
    vol444.innerHTML="10"
    ireading444.innerHTML="0"
    update()
    v=13;

  }

}
function ti555v() {
  if (v== 16) {
    aq555.style.transform = "translate(320%,0%) ";
    phand11.style.visibility = "visible";
    phand11.style.transform = "translate(-1150%,-500%)rotate(90deg)"
    vol555.innerHTML="10"
    ireading555.innerHTML="0"

    update()
    v=17;

  }

}
/**********************final table*************************** */
const utable = document.getElementById('usertable');
  const submitButton = document.getElementById('submitresult');
  const first=document.getElementById('first')
  const second=document.getElementById('second')
  const third=document.getElementById('third')
  const fourth=document.getElementById('fourth')
  const fifthr =document.getElementById('fifth')

  const first1=document.getElementById('first1')
  const second2=document.getElementById('second2')
  const third3=document.getElementById('third3')
  const fourth4=document.getElementById('fourth4')
  const fifth5=document.getElementById('fifth5')

  var myinput=document.querySelector(".myinput")
  submitButton.disabled = false; // Initially disable submit button

  // Function to check if all inputs in the table are filled
  function areAllInputsFilled() {
    const inputs = utable.querySelectorAll('input');
    return !Array.from(inputs).some(input => input.value === '');
  }
  var j1=document.querySelector("#j1")
var j2=document.querySelector("#j2")
var j3=document.querySelector("#j3")
var j4=document.querySelector("#j4")
var j5=document.querySelector("#j5")
var k1=document.querySelector("#k1")
var k2=document.querySelector("#k2")
var k3=document.querySelector("#k3")
var k4=document.querySelector("#k4")
var k5=document.querySelector("#k5")
var fifth=document.querySelector("#fifth")


// Event listener for submit button click (can be changed to other events)
submitButton.addEventListener('click', () => {
  if (areAllInputsFilled()) {
    first.disabled=true;
    second.disabled=true;
    third.disabled=true;
    fourth.disabled=true;
    fifthr.disabled=true;
    first1.disabled=true;
    second2.disabled=true;
    third3.disabled=true;
    fourth4.disabled=true;
    fifth5.disabled=true;
  
    submitButton.disabled =true; 
    j1.innerText="2.5"
    j2.innerText="3.7"
    j3.innerText="4.2"
    j4.innerText="2.9"
    j5.innerText="3"

    k1.innerText="0.5"
    k2.innerText="0.336"
    k3.innerText="0.22"
    k4.innerText="0.125"
    k5.innerText="0.08"
    update();
    
    alert('All inputs are filled!');
  } else {
    alert('Please fill in all required fields.');
  }
});

const arrow = document.querySelector(".arrow");              
 setTimeout(() => {
            
 });








